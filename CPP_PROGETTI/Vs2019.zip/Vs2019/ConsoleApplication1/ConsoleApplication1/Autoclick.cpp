#include "pch.h"

#include <iostream>
#include <windows.h>

using namespace std;

int main1(int a, char* b[]) {
	int n = 1;
	int x=0;
	int y=0;
	int sleepy = 30000; // ogni mezzo minuto
	int times = 120; // per un'ora (120 * mezzo minuto)
	int done = 0;
	string choice;

	cout << "Auto clicker avviato" << endl;
	cout << " " << endl;

	mouse_event(MOUSEEVENTF_MOVE, 100, 0, 0, 0);

	while (done <= times) {
		Sleep(sleepy);
		mouse_event(MOUSEEVENTF_LEFTDOWN, x, y, 0, 0);
		mouse_event(MOUSEEVENTF_LEFTUP, x, y, 0, 0);
		done++;
	}

	cout << "Auto clicker terminato" << endl;
	cout << " " << endl;
	return 0;
}