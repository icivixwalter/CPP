#include "pch.h"
#include "MousePosition.h"
#include <iostream>
#include <windows.h>

using namespace std;

int main(int a, char* b[]) {
	// AUTOCLICK
	int n = 1;
	int x = 0;
	int y = 0;
	int sleepy = 30000; // ogni mezzo minuto
	int times = 120; // per un'ora (120 * mezzo minuto)
	int done = 0;
	// POSIZIONE
	POINT mouse, old_mouse;
	if (!GetCursorPos(&mouse)) return -1;
	old_mouse = mouse;

	cout << "Auto clicker avviato" << endl;
	cout << " " << endl;

	mouse_event(MOUSEEVENTF_MOVE, 100, 0, 0, 0);

	// CREO IL 2� THREAD
	HANDLE h = CreateThread(
		NULL,	//contiene flag come ad esempio: handle pu� essere ereditato?
		0,		//dimensione dello stack del thread. Default = 0
		(PTHREAD_START_ROUTINE)posizione_mouse, //nome (indirizzo) funzione iniziale 
		NULL,	//puntatore ai parametri della funzione iniziale   
		0,		//non ci interessa.
		NULL);	// puntatore tid
	
		
	while (done <= times) {
		Sleep(sleepy);
		mouse_event(MOUSEEVENTF_LEFTDOWN, x, y, 0, 0);
		mouse_event(MOUSEEVENTF_LEFTUP, x, y, 0, 0);
		done++;
	}

	// TERMINO IL 2� THREAD
	DWORD exitCode = 0; 
	TerminateThread(h, exitCode);
	GetExitCodeThread(h, &exitCode);


	cout << "Auto clicker terminato. Thread Posizione Mouse terminato con valore " << exitCode << endl;
	cout << " " << endl;

}