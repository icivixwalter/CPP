#pragma once

int posizione_mouse();
